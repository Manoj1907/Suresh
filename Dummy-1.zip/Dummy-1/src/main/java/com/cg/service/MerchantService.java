package com.cg.service;

import com.cg.beans.Merchant;
import com.cg.beans.Product;

public interface MerchantService {

	void registerMerchant(Merchant merchant);


	void registerProduct(Product p);

}
