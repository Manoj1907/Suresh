package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.beans.Merchant;
import com.cg.beans.Product;
import com.cg.dao.MerchantDao;
import com.cg.dao.ProductDAO;

@Service
public class MerchantServiceImpl implements MerchantService{
	
	
	@Autowired
	MerchantDao dao;
	
	@Autowired
	ProductDAO pro;
	
	@Override
	public void registerMerchant(Merchant merchant) {
		dao.save(merchant);
		
	}

	@Override
	public void registerProduct(Product p) {
		pro.save(p);
		
	}

}
