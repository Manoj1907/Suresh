package com.cg.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.beans.Merchant;

@Repository
public interface MerchantDao extends JpaRepository<Merchant, Integer> {


	public Merchant findByMerchantEmail(String emailId);
	
	public Merchant findByMerchantId( int productId);

}
