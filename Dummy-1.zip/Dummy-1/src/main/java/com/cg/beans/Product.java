package com.cg.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "Productdetail")

public class Product {

	@Id
	@Column(name = "productid")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int productId;
	@Size(max = 20)
	@Column(name = "productname")
	@NotNull
	private String productName;
	
	@Column(name = "productcategory")
	@Size(max = 15)
	@NotNull
	private String productCategory;
	@Size(max = 15)
	@Column(name = "productbrand")
	@NotNull
	private String productBrand;
	@Column(name = "productmodel")
	@Size(max = 15)
	@NotNull
	private String productModel;
	@Size(max = 15)
	@Column(name = "producttype")
	@NotNull
	private String productType;
	@Size(max = 100)
	@Column(name = "productDiscount")
	@NotNull
	private String productDiscount;
	@Column(name = "productprice")
	@NotNull
	private String productPrice;

	public String getProductPrice() {
		return productPrice;
	}

	public void setProductPrice( String productPrice) {
		this.productPrice = productPrice;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}


	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public String getProductBrand() {
		return productBrand;
	}

	public void setProductBrand(String productBrand) {
		this.productBrand = productBrand;
	}

	public String getProductModel() {
		return productModel;
	}

	public void setProductModel(String productModel) {
		this.productModel = productModel;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public @Size(max = 100) @NotNull String getProductDiscount() {
		return productDiscount;
	}

	public void setProductDiscount(@Size(max = 100) @NotNull String productDiscount) {
		this.productDiscount = productDiscount;
	}

	

}
