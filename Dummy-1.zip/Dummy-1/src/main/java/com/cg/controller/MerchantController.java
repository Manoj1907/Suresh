package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.beans.Product;
import com.cg.service.MerchantService;

@RestController
public class MerchantController {

	@Autowired MerchantService mservice;

	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String fileinsertmerchant(@RequestBody Product p) {
		mservice.registerProduct(p);
		return "AddProductsByMerchant";
	}
	
	@RequestMapping(value="/delete",  method=RequestMethod.DELETE)
	public String deleteproduct(@RequestBody Product p) {
		mservice.registerProduct(p);
		return "DeleteProductsByMerchant";
	}

}
