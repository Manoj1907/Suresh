package com.cg.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


@Entity
@Table(name = "merchantdetail")
public class Merchant {

	@Id
	@Column(name="merchantid")
	@NotNull
	private int merchantid;
	@Column(name = "merchantname")
	@Size(max = 20)
	private String merchantName;
	@Column(name = "email")
	@Email
	@Size(max = 30)
	private String merchantEmail;
	@Column(name = "mobileno")
	@Size(max = 10)
	private String merchantMobileNumber;
	@Column(name = "address")
	@Size(max = 100)
	private String merchantAddress;
	@Column(name = "storename")
	@NotNull
	@Size(max = 20)
	private String merchantStoreName;
	@Column(name = "rating")
	@Max(5)
	@Min(1)
	private int Rating;
	@ManyToMany(cascade = CascadeType.ALL)
	private List<Product> products;
	public int getMerchantid() {
		return merchantid;
	}
	public void setMerchantid(int merchantid) {
		this.merchantid = merchantid;
	}
	public String getMerchantName() {
		return merchantName;
	}
	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}
	public String getMerchantEmail() {
		return merchantEmail;
	}
	public void setMerchantEmail(String merchantEmail) {
		this.merchantEmail = merchantEmail;
	}
	public String getMerchantMobileNumber() {
		return merchantMobileNumber;
	}
	public void setMerchantMobileNumber(String merchantMobileNumber) {
		this.merchantMobileNumber = merchantMobileNumber;
	}
	public String getMerchantAddress() {
		return merchantAddress;
	}
	public void setMerchantAddress(String merchantAddress) {
		this.merchantAddress = merchantAddress;
	}
	public String getMerchantStoreName() {
		return merchantStoreName;
	}
	public void setMerchantStoreName(String merchantStoreName) {
		this.merchantStoreName = merchantStoreName;
	}
	public int getRating() {
		return Rating;
	}
	public void setRating(int rating) {
		Rating = rating;
	}
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	@Override
	public String toString() {
		return "Merchant [merchantid=" + merchantid + ", merchantName=" + merchantName + ", merchantEmail="
				+ merchantEmail + ", merchantMobileNumber=" + merchantMobileNumber + ", merchantAddress="
				+ merchantAddress + ", merchantStoreName=" + merchantStoreName + ", Rating=" + Rating + ", products="
				+ products + "]";
	}
	
}
