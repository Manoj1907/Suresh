package com.cg.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="producttable")
public class Product {
	
	@Id
	@Column(name="prodid")
	@NotNull
	private int prodId;
	@Column(name="prodname")
	private String productName;
	@Column(name="prodimageurl")
	@NotNull
	private String productImageUrl;
	@Column(name="prodcategory")
	@NotNull
	private String productCategory;
	@Column(name="prodbrand")
	@NotNull
	private String prodBrand;
	@Column(name="prodtype")
	@NotNull
	private String prodType;
	@Column(name="prodprice")
	@NotNull
	private double prodPrice;
	public int getProdId() {
		return prodId;
	}
	public void setProdId(int prodId) {
		this.prodId = prodId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductImageUrl() {
		return productImageUrl;
	}
	public void setProductImageUrl(String productImageUrl) {
		this.productImageUrl = productImageUrl;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public String getProdBrand() {
		return prodBrand;
	}
	public void setProdBrand(String prodBrand) {
		this.prodBrand = prodBrand;
	}
	public String getProdType() {
		return prodType;
	}
	public void setProdType(String prodType) {
		this.prodType = prodType;
	}
	public double getProdPrice() {
		return prodPrice;
	}
	public void setProdPrice(double prodPrice) {
		this.prodPrice = prodPrice;
	}
	

}
