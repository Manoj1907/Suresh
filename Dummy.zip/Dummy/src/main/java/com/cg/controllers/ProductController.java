package com.cg.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.Product;
import com.cg.service.ProductService;


@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired private ProductService service;
	
	@RequestMapping(value="/add",method=RequestMethod.POST,
			consumes="application/json")
			public ResponseEntity<String> save(@RequestBody Product product){
				System.out.println("Save new product");
				service.save(product);
				return new ResponseEntity<>("Product added!" ,HttpStatus.OK);
			}
	
	@RequestMapping(value="/delete", method=RequestMethod.DELETE, consumes="application/json")
	public ResponseEntity<String> delete(@RequestBody Product prodId){
		System.out.println("Product deleted");
		service.delete(prodId);
		return new ResponseEntity<>("Product deleted!" ,HttpStatus.OK);
		}

	@RequestMapping(value="/update",method=RequestMethod.PUT,
			consumes="application/json")
			public ResponseEntity<String> update(@RequestBody Product prodId){
				System.out.println("update the stock");
				service.update(prodId);
				return new ResponseEntity<>("Product updated!" ,HttpStatus.OK);
			}
	

	@RequestMapping(value="/find",method=RequestMethod.GET,
			consumes="application/json")
			public ResponseEntity<String> find(@RequestBody Product prodId){
				System.out.println("update the stock");
				service.find(prodId);
				return new ResponseEntity<>("Product updated!" ,HttpStatus.OK);
			}
}
