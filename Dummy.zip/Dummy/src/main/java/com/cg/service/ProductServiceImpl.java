package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.dao.ProductDao;
import com.cg.model.Product;


public class ProductServiceImpl implements ProductService {

	@Autowired private ProductDao dao;
	@Override
	public void save(Product product) {
		dao.save(product);
		
		

	}

	@Override
	public void delete(Product prodId) {
		dao.delete(prodId);
	

	}

	@Override
	public void update(Product prodId) {
		dao.save(prodId);
		

	}

	@Override
	public void find(Product prodId) {
		dao.findAll();
		// TODO Auto-generated method stub
		
	}

}
