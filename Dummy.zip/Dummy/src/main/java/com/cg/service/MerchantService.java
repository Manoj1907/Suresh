package com.cg.service;

import com.cg.model.Merchant;
import com.cg.model.Product;

public interface MerchantService {



	void registerMerchant(Merchant merchant);

	
}
