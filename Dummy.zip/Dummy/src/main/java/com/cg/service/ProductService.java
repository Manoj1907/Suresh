package com.cg.service;

import com.cg.model.Product;

public interface ProductService {
	
	public void save(Product product);
	public void delete(Product prodId);
	public void update(Product prodId);
	public void find(Product prodId);

}
