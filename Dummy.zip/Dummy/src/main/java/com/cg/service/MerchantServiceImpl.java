package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.dao.MerchantDao;
import com.cg.model.Merchant;
import com.cg.model.Product;



public class MerchantServiceImpl implements MerchantService {

	@Autowired private MerchantDao dao;

	@Override
	public void registerMerchant(Merchant merchant) {
		dao.save(merchant);
		
	}
	





}
